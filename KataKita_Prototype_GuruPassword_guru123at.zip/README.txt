KATAKITA — VERSI PROTOTAIP SEKOLAH

Tema: Cream + Dark Brown
Fokus: Bahasa Melayu sekolah menengah

Fungsi:
- Login Pelajar / Guru
- Dashboard berasingan
- Nota Bahasa Melayu
- Guru boleh tambah nota dan lampiran fail
- Kuiz Bahasa Melayu
- Guru boleh cipta kuiz dan lampiran bahan rangsangan
- Karangan: pelajar hantar, guru semak markah dan maklum balas
- Tugasan
- Misi Berkumpulan
- Pencapaian
- Bank Bahan Guru
- Analitik & laporan
- Markah pelajar hanya dipaparkan kepada guru

Kata laluan guru prototaip:
guru123@

Had prototaip:
Data dan lampiran disimpan dalam localStorage pelayar. Ia belum dikongsi antara telefon/peranti berlainan.
Untuk penggunaan sekolah sebenar, sambungkan authentication + pangkalan data/server (contoh Supabase/Firebase atau infrastruktur sekolah/KPM yang diluluskan).
